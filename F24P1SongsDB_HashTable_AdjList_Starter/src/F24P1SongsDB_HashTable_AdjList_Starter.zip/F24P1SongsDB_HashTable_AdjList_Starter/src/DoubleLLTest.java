

import static org.junit.Assert.*;
import student.TestCase;
import org.junit.Test;

/**
 * This is the test class for DoubleLL
 * 
 * @author krishnapatel and nitinankareddy
 * @version Sep 17, 2024
 */
public class DoubleLLTest {
    
    private DoubleLL doubleLL;

    
    public void setUp()
    {
        doubleLL = new DoubleLL();
    }
    @Test
    public void testAddRemoveNode() {
        
        assertTrue(doubleLL.isEmpty());
        doubleLL.add(10);
        doubleLL.add(20);
        doubleLL.add(30);
        
        assertFalse(doubleLL.isEmpty());
        
        assertTrue(doubleLL.contains(10));
        assertTrue(doubleLL.contains(20));
        assertTrue(doubleLL.contains(30));
        
        
        doubleLL.removeFirst();
        assertFalse(doubleLL.contains(10));
        assertTrue(doubleLL.contains(20));
        assertTrue(doubleLL.contains(30));
        
        doubleLL.remove(20);
        doubleLL.remove(30);
        
        
        assertTrue(doubleLL.isEmpty());
        
    }

}