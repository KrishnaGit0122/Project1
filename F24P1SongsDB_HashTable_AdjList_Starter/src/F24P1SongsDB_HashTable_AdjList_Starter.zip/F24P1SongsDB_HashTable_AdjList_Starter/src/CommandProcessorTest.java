

/**
 * This is the test class for CommandProcessor
 * 
 * @author nitinankareddy and krishnapatel
 * @version Sep 17, 2024
 *
 */
public class CommandProcessorTest extends student.TestCase {
    private CommandProcessor cp;
    private Controller controller;

    /**
     * This is the setUp to make a new controller with size 5 for the table
     */
    public void setUp() {
        controller = new Controller(5);
        cp = new CommandProcessor(controller);
    }


    /**
     * This is the testing if the Command Processor reads the file
     */
    public void testReadLines() {
        cp.readLines("P1_sampleInput.txt");

    }

}