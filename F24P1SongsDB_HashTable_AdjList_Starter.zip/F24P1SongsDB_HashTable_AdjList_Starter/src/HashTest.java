import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import student.TestCase;

/**
 * Tests for Hash class.
 */
public class HashTest extends TestCase {
    /**
     * Private hash table object for testing.
     */
    private Hash hashTable;

    /**
     * Setup method initializes a new hash table with capacity of 10.
     */
    public void setUp() {
        hashTable = new Hash(10);
    }

    /**
     * Tests the static hashing function 'h'.
     */
    public void testSfold() throws Exception {
        assertTrue(Hash.h("a", 10000) == 97);
        assertTrue(Hash.h("b", 10000) == 98);
        assertTrue(Hash.h("aaaa", 10000) == 1873);
        assertTrue(Hash.h("aaab", 10000) == 9089);
        assertTrue(Hash.h("baaa", 10000) == 1874);
        assertTrue(Hash.h("aaaaaaa", 10000) == 3794);
        assertTrue(Hash.h("Long Lonesome Blues", 10000) == 4635);
        assertTrue(Hash.h("Long   Lonesome Blues", 10000) == 4159);
        assertTrue(Hash.h("long Lonesome Blues", 10000) == 4667);
    }

    /**
     * Tests the resizing functionality when the table reaches capacity.
     */
    public void testDoubleSizeCapacity() {
        hashTable.insert("Key1", new Node(1), true);
        hashTable.insert("Key2", new Node(2), true);
        hashTable.insert("Key3", new Node(3), true);
        hashTable.insert("Key4", new Node(4), false);
        hashTable.insert("Key5", new Node(5), true);

        assertEquals(10, hashTable.getCapacity().intValue());

        // Trigger size doubling
        hashTable.insert("Key6", new Node(6), true);

        // Capacity should now be doubled
        assertEquals(20, hashTable.getCapacity().intValue());
    }

    /**
     * Verifies that elements are copied correctly during resizing.
     */
    public void testElementsCopiedOnResize() {
        hashTable.insert("Key1", new Node(1), true);
        hashTable.insert("Key2", new Node(2), false);
        hashTable.insert("Key3", new Node(3), true);

        // Trigger double size
        hashTable.insert("Key4", new Node(4), true);
        hashTable.insert("Key5", new Node(5), true);
        hashTable.insert("Key6", new Node(6), false);

        // Ensure all elements are still present
        assertNotNull(hashTable.find("Key1"));
        assertNotNull(hashTable.find("Key2"));
        assertNotNull(hashTable.find("Key3"));
        assertNotNull(hashTable.find("Key4"));
        assertNotNull(hashTable.find("Key5"));
        assertNotNull(hashTable.find("Key6"));
    }

    /**
     * Tests that tombstones are not copied during resizing.
     */
    public void testTombstonesNotCopiedOnResize() {
        hashTable.insert("Key1", new Node(1), true);
        hashTable.insert("Key2", new Node(2), false);
        hashTable.insert("Key3", new Node(3), true);

        // Remove to create a tombstone
        hashTable.remove("Key2", true);

        // Trigger resize
        hashTable.insert("Key4", new Node(4), true);
        hashTable.insert("Key5", new Node(5), true);
        hashTable.insert("Key6", new Node(6), false);

        // Ensure tombstone record is not copied
        assertNull(hashTable.find("Key2"));
    }

    /**
     * Tests quadratic probing collision resoluton.
     */
    public void testQuadraticProbingCollisionResolution() {
        hashTable.insert("key1", new Node(1), true);
        hashTable.insert("key2", new Node(2), true);

        assertNotNull(hashTable.find("key1"));
        assertNotNull(hashTable.find("key2"));
    }

    /**
     * Tests table resizing with quadratic probing.
     */
    public void testProbingDuringResize() {
        hashTable.insert("Key1", new Node(1), true);
        hashTable.insert("Key2", new Node(2), true);
        hashTable.insert("Key3", new Node(3), true);
        hashTable.insert("Key4", new Node(4), true);
        hashTable.insert("Key5", new Node(5), true);

        // Trigger resize
        hashTable.insert("Key6", new Node(6), true);

        // Ensure all records are still present after resizing
        assertNotNull(hashTable.find("Key1"));
        assertNotNull(hashTable.find("Key2"));
        assertNotNull(hashTable.find("Key3"));
        assertNotNull(hashTable.find("Key4"));
        assertNotNull(hashTable.find("Key5"));
        assertNotNull(hashTable.find("Key6"));
    }

    /**
     * Test reassigning records to the new table after resizing.
     */
    public void testAllRecordsReassignedAfterResize() {
        hashTable.insert("Key1", new Node(1), true);
        hashTable.insert("Key2", new Node(2), true);
        hashTable.insert("Key3", new Node(3), true);
        hashTable.insert("Key4", new Node(4), true);
        hashTable.insert("Key5", new Node(5), true);

        // Trigger resize
        hashTable.insert("Key6", new Node(6), true);

        // Insert another element to verify new array is being used
        hashTable.insert("Key7", new Node(7), true);
        assertNotNull(hashTable.find("Key7"));

        // Ensure previous records are still intact
        assertNotNull(hashTable.find("Key1"));
        assertNotNull(hashTable.find("Key6"));
    }

    /**
     * Tests inserting a song into the hash table.
     */
    public void testInsertSong() {
        hashTable.insert("songKey", new Node(1), true);
        assertNotNull(hashTable.find("songKey"));
    }

    /**
     * Tests inserting an artist into the hash table.
     */
    public void testInsertArtist() {
        hashTable.insert("artistKey", new Node(2), false);
        assertNotNull(hashTable.find("artistKey"));
    }

    /**
     * Tests inserting a duplicate song into the hash table.
     */
    public void testInsertSongDuplicate() {
        hashTable.insert("songKey", new Node(1), true);
        hashTable.insert("songKey", new Node(1), true);
        assertNotNull(hashTable.find("songKey"));
    }

    /**
     * Tests removing a song from the table.
     */
    public void testRemoveSong() {
        hashTable.insert("songKey", new Node(1), true);
        hashTable.remove("songKey", true);
        assertNull(hashTable.find("songKey"));
    }

    /**
     * Tests printing artists, ensuring tombstones are handled properly.
     */
    public void testPrintArtistWithTombstone() {
        hashTable.insert("artist1", new Node(1), false);
        hashTable.insert("artist2", new Node(2), false);
        hashTable.remove("artist2", false);

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(output));

        hashTable.print(false);

        System.setOut(originalOut);
        String outputString = output.toString();

        assertTrue(outputString.contains("TOMBSTONE"));
        assertTrue(outputString.contains("|artist1|"));
        //assertTrue(outputString.contains("|artist3|"));
        assertFalse(outputString.contains("total artists: 2"));
    }
}
