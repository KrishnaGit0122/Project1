import student.TestCase;

/**
 * @author <Put something here>
 * @version <Put something here>
 */
public class HashTest extends TestCase {
    private Hash hash;
    /**
     * Sets up the tests that follow. In general, used for initialization
     */
    public void setUp() {
        hash = new Hash(5);
          
    }


    /**
     * Check out the sfold method
     *
     * @throws Exception
     *             either a IOException or FileNotFoundException
     */
    public void testSfold() throws Exception {
        assertTrue(Hash.h("a", 10000) == 97);
        assertTrue(Hash.h("b", 10000) == 98);
        assertTrue(Hash.h("aaaa", 10000) == 1873);
        assertTrue(Hash.h("aaab", 10000) == 9089);
        assertTrue(Hash.h("baaa", 10000) == 1874);
        assertTrue(Hash.h("aaaaaaa", 10000) == 3794);
        assertTrue(Hash.h("Long Lonesome Blues", 10000) == 4635);
        assertTrue(Hash.h("Long   Lonesome Blues", 10000) == 4159);
        assertTrue(Hash.h("long Lonesome Blues", 10000) == 4667);
    }
    
    public void testInsert( ) {
        hash.insert("test1");
        hash.insert("test2");
        hash.insert("test3");
        
        assertTrue(hash.contains("test2"));
        assertFalse(hash.contains("test5"));
        hash.insert("test4");
        hash.insert("test5");
        hash.insert("test6");
        hash.insert("test6");
        hash.remove("test6");
        assertFalse(hash.contains("test6"));
    }
    
    public void testRemove() {
        hash.insert("test1");
        hash.insert("test2");
        hash.insert("test3");
        hash.remove("test1");
        assertFalse(hash.contains("test1"));
        assertTrue(hash.contains("test2"));
        //assertFalse(hash.remove(null));
    }
    
    public void testFind() {
        hash.insert("test1");
        hash.insert("test2");
        hash.insert("test3");
        
        assertEquals("test1", hash.find("test1"));
        assertNull(hash.find("test"));
        
        hash.remove(("test1"));
        assertNull(hash.find("test1"));
        
        
    }
}
