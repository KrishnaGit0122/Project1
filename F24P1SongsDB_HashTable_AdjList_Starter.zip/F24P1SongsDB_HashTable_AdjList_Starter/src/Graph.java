/**
 * @author nitinankareddy
 *
 */
public class Graph {
    private DoubleLL[] vertex;  // Array of adjacency lists for the graph
    private DoubleLL freeSlots; // Doubly linked list to track freed slots
    private int numberOfNodes;  // Number of nodes in the graph
    private int[] parent;
    private int[] rank;


    public Graph(int initialSize) {
        this.vertex = new DoubleLL[initialSize];
        this.numberOfNodes = 0;
        this.freeSlots = new DoubleLL(); 
        this.parent = new int[initialSize];
        this.rank = new int[initialSize];
        
        // Initialize each node to be its own parent, and rank to 0
        for (int i = 0; i < initialSize; i++) {
            parent[i] = -1;
            rank[i] = 0;
        }
        this.expand();
    }
    
    public int find(int curr) {
        if (parent[curr] == -1) {
            return curr;  // If the node is a root, return itself
        }
        parent[curr] = find(parent[curr]);  // Path compression
        return parent[curr];  // Return the root of the set
    }
    
    public void union(int a, int b) {
        int root1 = find(a);  // Find the root of node a
        int root2 = find(b);  // Find the root of node b

        if (root1 != root2) {  // Only merge if they are in different components
            if (rank[root1] > rank[root2]) {
                parent[root2] = root1;  // Attach root2's tree to root1
            } else if (rank[root1] < rank[root2]) {
                parent[root1] = root2;  // Attach root1's tree to root2
            } else {
                parent[root2] = root1;  // Arbitrarily attach root2 to root1
                rank[root1]++;  // Increase the rank of root1 since the trees were of equal height
            }
        }
    }
    
    public void connectedComponents() {
        int[] componentSize = new int[vertex.length]; // To track the size of each component
        int numComponents = 0; // To count the number of connected components
        int largestComponentSize = 0; // To track the size of the largest component
        
        System.out.println("CHECK1");

        // Perform union operations for all edges in the graph
        for (int i = 0; i < vertex.length; i++) {
            System.out.println("UNION");
            if (vertex[i] != null) {
                System.out.println("UNION IF");
                for (int j = 0; j < vertex[i].size(); j++) {
                    System.out.println("UNION IF2");
                    int neighbor = vertex[i].get(j);  // Get the neighbor from the adjacency list
                    union(i, i++);  // Union the current node and its neighbor
                    System.out.println("UNION"+i);
                }
            }
        }
        
        System.out.println("CHECK2");

        // Count the number of connected components and find the largest one
        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null) {
                int root = find(i);  // Find the root of the current node
                componentSize[root]++;  // Increment the size of the component that has this root
            }
        }
        
        System.out.println("CHECK3");

        // Calculate the number of components and find the largest component
        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null && componentSize[i] > 0) {
                numComponents++;  // This root represents a component
                if (componentSize[i] > largestComponentSize) {
                    largestComponentSize = componentSize[i];  // Track the largest component
                }
            }
        }
        
        System.out.println("CHECK4");

        // Print the number of components and the size of the largest one
        System.out.println("Number of connected components: " + numComponents);
        System.out.println("Size of the largest connected component: " + largestComponentSize);
    }



    
//    public int find(int curr) {
//       
//        //parent[curr] = find(parent[curr]);
//        
//        while (parent[curr] != -1) {
//            curr = parent[curr];
//        }
//        return curr;
//      }
//    
//    public void union(int a, int b) {
//        int root1 = find(a);     // Find root of node a
//        int root2 = find(b);     // Find root of node b
//        if (root1 != root2) {          // Merge with weighted union
//          if (rank[root2] > rank[root1]) {
//            parent[root1] = root2;
//            rank[root2] += rank[root1];
//          } else {
//            parent[root2] = root1;
//            rank[root1] += rank[root2];
//          }
//        }
//      }
//    
//    public int countConnectedComponents() {
//        
//        for (int i = 0; i < vertex.length; i++) {
//            for (int j = 0; j < vertex[i].size(); j++) {
//                this.union(j, j + 1);
//            }
//        }
//        
//        for (int i = 0; i < vertex.length; i++) {
//            int
//            for (int j = 0; j < vertex[i].size(); j++) {
//                
//            }
//        }
////        
////        return largest;
////        // We assume that node indices are within the range 0 to vertex.length - 1
////        boolean[] visitedRoots = new boolean[vertex.length];
////        int count = 0;
////
////        for (int i = 0; i < vertex.length; i++) {
////            if (vertex[i] != null) {
////                int root = find(i);  // Find the root of the node
////                if (!visitedRoots[root]) {
////                    visitedRoots[root] = true;  // Mark this root as visited
////                    count++;  // Increment the component count
////                }
////            }
////        }
////
////        return count;
//    }
    
    

    public boolean graphInsert(int songIndex, int artistIndex) {
        
        
        
        if (numberOfNodes == 0) {
            this.newNode(artistIndex);
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        }
       
        if (this.hasEdge(songIndex, artistIndex)) {
            return true;
        }
        
        
        if (this.containsNode(songIndex) && this.containsNode(artistIndex)) {
            this.newNode(artistIndex);
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        }
        
        if (this.containsNode(artistIndex)) {
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        }
        
        if (this.containsNode(songIndex)) {
            this.newNode(artistIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
            
        }
        
        this.addEdge(songIndex, artistIndex);
        return false; 
    }
    
    public void graphRemove(int artistIndex) {
        this.removeNode(artistIndex);
    }
        
    
    public void newNode(int index) { 
        if (numberOfNodes == vertex.length) {
            this.expand();  // Expand graph if full
        }
        vertex[index] = new DoubleLL();  // Add new adjacency list for the node
        numberOfNodes++;
        
    }
    
    private void expand() {
        DoubleLL[] newVertex = new DoubleLL[vertex.length * 2];
        System.arraycopy(vertex, 0, newVertex, 0, vertex.length);
        vertex = newVertex;
    }
    
    public void addEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].add(node2);
            vertex[node2].add(node1);
            
            // Union the two nodes
            //union(node1, node2);
        }
    }


    // Method to check if an edge exists between two nodes
    public boolean hasEdge(int node1, int node2) {
        return vertex[node1] != null && vertex[node2] != null && vertex[node1].contains(node2);
    }

    // Method to remove an edge between two nodes
    public void removeEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].remove(node2);
            vertex[node2].remove(node1);
        }
    }
    
    public void removeNode(int index) {
        if (index == -1) {
            return;
        }
        
        if (this.containsNode(index)) {
            while(!vertex[index].isEmpty()) {
                int currIndex = vertex[index].findIndex();
                if (currIndex!= -1) {
                    this.removeEdge(index, currIndex);
                }
            }
        }
        vertex[index] = null;
    }

    // Method to remove a node and all its edges
//    public void removeNode(int node) {
//        if (vertex[node] != null) {
//            // Remove all edges connected to this node
//            while (!vertex[node].isEmpty()) {
//                int adjacentNode = vertex[node].removeFirst();
//                vertex[adjacentNode].remove(node);  // Remove reciprocal edge
//            }
//            vertex[node] = null;
//            freeSlots.add(node);  // Add the removed node index to freeSlots for reuse
//        }
//    }
    
    public int getNumberOfNodes()
    {
        return numberOfNodes;
    }
    
    public boolean containsNode(int index) {
        
        if (vertex[index] == null || index == -1) {
            return false;
        }
        return true;

               
    }
    
    
    
    
    
    
    
    

}
