

/**
 * @author nitinankareddy
 *
 */
public class Graph {
    private DoubleLL[] vertex;  // Array of adjacency lists for the graph
    private DoubleLL freeSlots; // Doubly linked list to track freed slots
    private int numberOfNodes;  // Number of nodes in the graph
    private int[] parent;
    private int[] rank;
    


    public Graph(int initialSize) {
        this.vertex = new DoubleLL[initialSize];
        this.numberOfNodes = 0;
        this.freeSlots = new DoubleLL(); 
//        this.parent = new int[initialSize];
//        this.rank = new int[initialSize];
        
        // Initialize each node to be its own parent, and rank to 0
       
        this.expand();
    }
    
    public void expandParent() {
        int[] newParent = new int[parent.length * 2];
        for (int i = 0; i < parent.length; i++) {
          newParent[i] = parent[i];
        
        }
        parent = newParent;
    }
    
    public void expandRank() {
        int[] newParent = new int[rank.length * 2];
        for (int i = 0; i < rank.length; i++) {
          newParent[i] = rank[i];
        
        }
        rank = newParent;
    }
    
    public int find(int curr) {
        if (curr > parent.length) {
            this.expandParent();
            this.expandRank();
        }
        
        while( parent[curr] != -1)
        {
            curr = parent[curr];// Return the root of the set
        }
        return curr;
    }

    
    public void union(int a, int b) {
        int rootA = find(a);  // Find the root of node a
        int rootB = find(b);  // Find the root of node b

        if (rootA != rootB) {  // Only merge if they are in different components
            if (rank[rootA] > rank[rootB]) {
                parent[rootB] = rootA;
                rank[rootA]++;// Attach rootB's tree to rootA
            } else if (rank[rootA] < rank[rootB]) {
                parent[rootA] = rootB;
                rank[rootB]++;// Attach rootA's tree to rootB
            } else {
                parent[rootB] = rootA;  // Arbitrarily attach rootB to rootA
                rank[rootA]++;  // Increase the rank of rootA since the trees were of equal height
            }
        }
    }
    
    public void connectedComponents() {
        
        this.parent = new int[numberOfNodes];
        this.rank = new int[numberOfNodes];
        
        for (int i = 0; i < numberOfNodes; i++) {
            parent[i] = -1;
            rank[i] = 0;
        }
        
       //int[] componentSize = new int[vertex.length]; // To track the size of each component
        int numComponents = 0; // To count the number of connected components
        int largestComponentSize = 0; // To track the size of the largest component
        
        // Perform union operations for all edges in the graph
        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null) {
                //System.out.println(vertex[i].size());
                for (int j = 0; j < vertex[i].size(); j++) {
                    int neighbor = vertex[i].get(j);  // Get the neighbor from the adjacency list
                    union(i, neighbor);  // Union the current node and its neighbor
                }
            }
        }

        // Count the number of connected components and find the largest one
        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null) {
                int root = find(i);  // Find the root of the current node
                rank[root]++;  // Increment the size of the component that has this root
            }
        }

        // Calculate the number of components and find the largest component
        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null && rank[i] > 0) {
                numComponents++;  // This root represents a component
                if (rank[i] > largestComponentSize) {
                    largestComponentSize = rank[i];  // Track the largest component
                }
            }
        }

        // Print the number of components and the size of the largest one
        System.out.println("Number of connected components: " + numComponents);
        System.out.println("Size of the largest connected component: " + largestComponentSize);
    }

    public boolean graphInsert(int songIndex, int artistIndex) {
        
        
        
        if (numberOfNodes == 0) {
            this.newNode(artistIndex);
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        } 
       
        if (this.hasEdge(songIndex, artistIndex)) {
            return true;
        }
        
        
        if (this.containsNode(songIndex) && this.containsNode(artistIndex)) {
            this.newNode(artistIndex);
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        }
        
        if (this.containsNode(artistIndex)) {
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
        }
        
        if (this.containsNode(songIndex)) {
            this.newNode(artistIndex);
            this.addEdge(songIndex, artistIndex);
            return false;
            
        }
        
        this.addEdge(songIndex, artistIndex);
        return false; 
    }
    
    public void graphRemove(int artistIndex) {
        this.removeNode(artistIndex);
    }
        
    
    public void newNode(int index) { 
        if (numberOfNodes == vertex.length) {
            this.expand();  // Expand graph if full
        }
        vertex[index] = new DoubleLL();  // Add new adjacency list for the node
        numberOfNodes++;
        
    }
    
    private void expand() {
        DoubleLL[] newVertex = new DoubleLL[vertex.length * 2];
        for (int i = 0; i < vertex.length; i++) {
            newVertex[i] = vertex[i];
        }
        vertex = newVertex;
        
    }

    
    public void addEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].add(node2);
            vertex[node2].add(node1);
            
            // Union the two nodes
            //union(node1, node2);
        }
    }


    // Method to check if an edge exists between two nodes
    public boolean hasEdge(int node1, int node2) {
        return vertex[node1] != null && vertex[node2] != null && vertex[node1].contains(node2);
    }

    // Method to remove an edge between two nodes
    public void removeEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].remove(node2);
            vertex[node2].remove(node1);
        }
    }
    
    public void removeNode(int index) {
        if (index == -1) {
            return;
        }
        
        if (this.containsNode(index)) {
            while(!vertex[index].isEmpty()) {
                int currIndex = vertex[index].findIndex();
                if (currIndex!= -1) {
                    this.removeEdge(index, currIndex);
                }
            }
        }
        vertex[index] = null;
    }

    // Method to remove a node and all its edges
//    public void removeNode(int node) {
//        if (vertex[node] != null) {
//            // Remove all edges connected to this node
//            while (!vertex[node].isEmpty()) {
//                int adjacentNode = vertex[node].removeFirst();
//                vertex[adjacentNode].remove(node);  // Remove reciprocal edge
//            }
//            vertex[node] = null;
//            freeSlots.add(node);  // Add the removed node index to freeSlots for reuse
//        }
//    }
    
    public int getNumberOfNodes()
    {
        return numberOfNodes;
    }
    
    public boolean containsNode(int index) {
        
        if (vertex[index] == null || index == -1) {
            return false;
        }
        return true;

               
    }
    

    
    
    
    
    
    
    
    

}
