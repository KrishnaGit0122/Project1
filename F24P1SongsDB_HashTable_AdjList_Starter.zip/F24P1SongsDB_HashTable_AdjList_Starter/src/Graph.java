/**
 * @author nitinankareddy
 *
 */
public class Graph {
    private DoubleLL[] vertex;  // Array of adjacency lists for the graph
    private DoubleLL freeSlots; // Doubly linked list to track freed slots
    private int numberOfNodes;  // Number of nodes in the graph
    private int[] parent;
    private int[] rank;


    public Graph(int initialSize) {
        this.vertex = new DoubleLL[initialSize];
        this.numberOfNodes = 0;
        this.freeSlots = new DoubleLL(); 
        this.parent = new int[initialSize];
        this.rank = new int[initialSize];
        
        // Initialize each node to be its own parent, and rank to 0
        for (int i = 0; i < initialSize; i++) {
            parent[i] = i;
            rank[i] = 0;
        }
    }
    
    public int find(int x) {
        int root = x;
        while (root != parent[root]) {
            root = parent[root];
        }

        
        while (x != root) {
            int next = parent[x];
            parent[x] = root;
            x = next;
        }

        return root;
    }
    
    public void union(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);
        
        if (rootX != rootY) {
            if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
        }
    }
    
    public int countConnectedComponents() {
        // We assume that node indices are within the range 0 to vertex.length - 1
        boolean[] visitedRoots = new boolean[vertex.length];
        int count = 0;

        for (int i = 0; i < vertex.length; i++) {
            if (vertex[i] != null) {
                int root = find(i);  // Find the root of the node
                if (!visitedRoots[root]) {
                    visitedRoots[root] = true;  // Mark this root as visited
                    count++;  // Increment the component count
                }
            }
        }

        return count;
    }

    public void graphInsert(int songIndex, int artistIndex) {
        
        if (this.hasEdge(songIndex, artistIndex)) {
            // check for duplicates
        }
        
        if (vertex[songIndex].isEmpty() && vertex[artistIndex].isEmpty()) {
            this.newNode(artistIndex);
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return;
        }
        
        if (vertex[songIndex].isEmpty()) {
            this.newNode(songIndex);
            this.addEdge(songIndex, artistIndex);
            return;
        }
        
        if (vertex[artistIndex].isEmpty()) {
            this.newNode(artistIndex);
            this.addEdge(songIndex, artistIndex);
            return;
            
        }
        
        this.addEdge(songIndex, artistIndex);
    }
    
    public void graphRemoveArtist(int artistIndex) {
        this.removeNode(artistIndex);
    }
        
    
    public void newNode(int index) { 
        if (numberOfNodes == vertex.length) {
            this.expand();  // Expand graph if full
        }
        vertex[index] = new DoubleLL();  // Add new adjacency list for the node
        numberOfNodes++;
        
    }
    
    private void expand() {
        DoubleLL[] newVertex = new DoubleLL[vertex.length * 2];
        System.arraycopy(vertex, 0, newVertex, 0, vertex.length);
        vertex = newVertex;
    }
    
    public void addEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].add(node2);
            vertex[node2].add(node1);
            
            // Union the two nodes
            union(node1, node2);
        }
    }


    // Method to check if an edge exists between two nodes
    public boolean hasEdge(int node1, int node2) {
        return vertex[node1] != null && vertex[node2] != null && vertex[node1].contains(node2);
    }

    // Method to remove an edge between two nodes
    public void removeEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].remove(node2);
            vertex[node2].remove(node1);
        }
    }

    // Method to remove a node and all its edges
    public void removeNode(int node) {
        if (vertex[node] != null) {
            // Remove all edges connected to this node
            while (!vertex[node].isEmpty()) {
                int adjacentNode = vertex[node].removeFirst();
                vertex[adjacentNode].remove(node);  // Remove reciprocal edge
            }
            vertex[node] = null;
            freeSlots.add(node);  // Add the removed node index to freeSlots for reuse
        }
    }
    
    public int getNumberOfNodes()
    {
        return numberOfNodes;
    }
    
    
    
    
    

}
