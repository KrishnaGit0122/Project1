/**
 * 
 */

/**
 * @author nitinankareddy
 *
 */
public class Graph {
    private DoubleLL[] vertex;  // Array of adjacency lists for the graph
    private DoubleLL freeSlots; // Doubly linked list to track freed slots
    private int numberOfNodes;  // Number of nodes in the graph

    public Graph(int initialSize) {
        this.vertex = new DoubleLL[initialSize];
        this.numberOfNodes = 0;
        this.freeSlots = new DoubleLL(); // Initializes a new linked list for free slots
    }
    
    public void newNode() {
        if (!freeSlots.isEmpty()) {
            // Reuse a slot from freeSlots
            int reusedIndex = freeSlots.removeFirst();
            vertex[reusedIndex] = new DoubleLL();  // Create a new adjacency list for the node
        } 
        
        else {
            if (numberOfNodes == vertex.length) {
                this.expand();  // Expand graph if full
            }
            vertex[numberOfNodes] = new DoubleLL();  // Add new adjacency list for the node
            numberOfNodes++;
        }
        
    }
    
    private void expand() {
        DoubleLL[] newVertex = new DoubleLL[vertex.length * 2];
        System.arraycopy(vertex, 0, newVertex, 0, vertex.length);
        vertex = newVertex;
    }
    
    public void addEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            // Add the edge (this assumes an undirected graph)
            vertex[node1].add(node2);
            vertex[node2].add(node1);
        }
    }

    // Method to check if an edge exists between two nodes
    public boolean hasEdge(int node1, int node2) {
        return vertex[node1] != null && vertex[node2] != null && vertex[node1].contains(node2);
    }

    // Method to remove an edge between two nodes
    public void removeEdge(int node1, int node2) {
        if (vertex[node1] != null && vertex[node2] != null) {
            vertex[node1].remove(node2);
            vertex[node2].remove(node1);
        }
    }

    // Method to remove a node and all its edges
    public void removeNode(int node) {
        if (vertex[node] != null) {
            // Remove all edges connected to this node
            while (!vertex[node].isEmpty()) {
                int adjacentNode = vertex[node].removeFirst();
                vertex[adjacentNode].remove(node);  // Remove reciprocal edge
            }
            vertex[node] = null;
            freeSlots.add(node);  // Add the removed node index to freeSlots for reuse
        }
    }
    
    
    
    
    

}
