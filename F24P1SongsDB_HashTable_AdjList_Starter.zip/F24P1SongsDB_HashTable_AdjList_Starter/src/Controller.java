/**
 * This is the class that understands which data structure the
 * commands are relayed to
 * 
 * @author krishnapatel and nitinankareddy
 * @version sep 17, 2024
 */

public class Controller {

    private Hash artists;
    private Hash songs;

    /**
     * This makes 2 new hash tables with the inputted capacities
     * 
     * @param initialCapacity
     */
    public Controller(int initialCapacity) {
        this.artists = new Hash(initialCapacity);
        this.songs = new Hash(initialCapacity);
    }


    /**
     * This method inserts an artist into the artist table
     * 
     * @param artist
     * @param artistNode
     * @return
     */
    public boolean insertArtist(String artist, Node artistNode) {
        return artists.insert(artist, artistNode, false);

    }


    /**
     * This method inserts a song into the song hash table
     * 
     * @param song
     * @param songNode
     * @return
     */
    public boolean insertSong(String song, Node songNode) {
        return songs.insert(song, songNode, true);
    }


    /**
     * This method removes an artist from the artist hash table
     * 
     * @param artist
     */
    public void removeArtist(String artist) {
        artists.remove(artist, false);
    }


    /**
     * This method removes a song from the song hash table
     * 
     * @param song
     */
    public void removeSong(String song) {
        songs.remove(song, true);
    }


    /**
     * This prints all of the artists present
     */
    public void printArtists() {
        artists.print(false);

    }


    /**
     * This prints all of the songs present in the table
     */
    public void printSongs() {
        songs.print(true);
    }


    public void printGraph() {
        songs.printGraph();
    }

}
