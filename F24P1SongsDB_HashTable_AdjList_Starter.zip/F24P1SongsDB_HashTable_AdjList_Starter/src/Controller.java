/**
 * 
 */

/**
 * @author nitinankareddy
 *
 */
public class Controller {
    
    private Hash artist;
    private Hash song;
    
    public void insert(String art, String sng) {
        
    }

    

}
