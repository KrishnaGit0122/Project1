
/**
 * @author nitinankareddy and krishnapatel
 *
 */
public class DoubleLL {
    
    private class DLLNode {
        int data;
        DLLNode prev;
        DLLNode next;

        public DLLNode(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    private DLLNode head; // Head of the list
    private DLLNode tail; // Tail of the list

    public DoubleLL() {
        head = null;
        tail = null;
    }

    // Add a node to the end of the list
    public void add(int data) {
        DLLNode newNode = new DLLNode(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Remove the first occurrence of a node with the specified data
    public void remove(int data) {
        DLLNode current = head;
        while (current != null) {
            if (current.data == data) {
                if (current.prev != null) {
                    current.prev.next = current.next;
                } else {
                    head = current.next; // Removing head
                }
                if (current.next != null) {
                    current.next.prev = current.prev;
                } else {
                    tail = current.prev; // Removing tail
                }
                return; // Data found and removed
            }
            current = current.next;
        }
    }

    // Remove and return the first node in the list
    public int removeFirst() {
        if (head == null) {
            throw new RuntimeException("List is empty");
        }
        int data = head.data;
        if (head == tail) { // Only one element in the list
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
        return data;
    }

    // Check if a node with the specified data exists
    public boolean contains(int data) {
        DLLNode current = head;
        while (current != null) {
            if (current.data == data) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Check if the list is empty
    public boolean isEmpty() {
        return head == null;
    }
}

