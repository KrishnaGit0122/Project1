
/**
 * @author nitinankareddy and krishnapatel
 *
 */
public class DoubleLL {
    
    private class DLLNode {
        Integer data;
        DLLNode prev;
        DLLNode next;
        

        public DLLNode(Integer data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    private DLLNode head; // Head of the list
    private DLLNode tail; // Tail of the list

    public DoubleLL() {
        head = null;
        tail = null;
    }

    // Add a node to the end of the list
    public void add(int data) {
        DLLNode newNode = new DLLNode(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Remove the first occurrence of a node with the specified data
    public void remove(int data) {
        DLLNode current = head;
        while (current != null) {
            if (current.data == data) {
                if (current.prev != null) {
                    current.prev.next = current.next;
                } else {
                    head = current.next; // Removing head
                }
                if (current.next != null) {
                    current.next.prev = current.prev;
                } else {
                    tail = current.prev; // Removing tail
                }
                return; // Data found and removed
            }
            current = current.next;
        }
    }
    
    public int findIndex() {
        DLLNode current = head;
        while (current != null) {
            if (current.data != null) {
                return current.data;
            }
            
            current = current.next;
        }
        return -1;
    }

    // Remove and return the first node in the list
    public int removeFirst() {
        if (head == null) {
            throw new RuntimeException("List is empty");
        }
        int data = head.data;
        if (head == tail) { // Only one element in the lis
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
        return data;
    }

    // Check if a node with the specified data exists
    public boolean contains(int data) {
        DLLNode current = head;
        while (current != null) {
            if (current.data == data) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
    
    public int size() {
        DLLNode current = head;
        int size = 0;
        while(current != null) {
            size++;
        }
        return size;
    }
    
    public Integer get(int index) {
//        if (index < 0 || index >= size()) {
//            throw new IndexOutOfBoundsException("Index out of bounds");
//        }

        // Optimized traversal
        DLLNode current;
        int mid = size() / 2;
        if (index <= mid) {
            current = head;
            for (int i = 0; i < index; i++) {
                current = current.next;
            }
        } else {
            current = tail;
            for (int i = size() - 1; i > index; i--) {
                current = current.prev;
            }
        }
        return current.data;
    }
    

    // Check if the list is empty
    public boolean isEmpty() {
        //System.out.print("HERE");
        return head == null;
    }
    
    public DLLNode getHead()
    {
        return head;
    }
}

