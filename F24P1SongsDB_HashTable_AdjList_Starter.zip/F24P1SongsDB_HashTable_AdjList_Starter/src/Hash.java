/**
 * Hash table class
 *
 * @author Nitin Ankareddy and Krishna Patel
 * @version <Put Something Here>
 */
public class Hash extends DLList {

    private DLList[] table;  // Array of doubly linked lists to handle collisions
    private int size;  // Number of elements in the table

    /**
     * Constructor to initialize the hash table with a specific length.
     * 
     * @param length The length of the hash table.
     */
    public Hash(int length) {
        table = new DLList[length];
        for (int i = 0; i < length; i++) {
            table[i] = new DLList();
        }
        size = 0;
    }

    /**
     * Compute the hash function
     * 
     * @param s
     *            The string that we are hashing
     * @param length
     *            Length of the hash table (needed because this method is
     *            static)
     * @return
     *         The hash function value (the home slot in the table for this key)
     */
    public static int h(String s, int length) {
        int intLength = s.length() / 4;
        long sum = 0;
        for (int j = 0; j < intLength; j++) {
            char[] c = s.substring(j * 4, (j * 4) + 4).toCharArray();
            long mult = 1;
            for (int k = 0; k < c.length; k++) {
                sum += c[k] * mult;
                mult *= 256;
            }
        } 

        char[] c = s.substring(intLength * 4).toCharArray();
        long mult = 1;
        for (int k = 0; k < c.length; k++) {
            sum += c[k] * mult;
            mult *= 256;
        }

        return (int) (Math.abs(sum) % length);
    }

    /**
     * Insert a string into the hash table.
     * 
     * @param s The string to be inserted.
     */
    public void insert(String s) {
        int index = h(s, table.length);  // Compute the hash value to find the index
        if (!table[index].contains(s)) {  // Only insert if it's not already in the list
            table[index].insert(s);  // Add the string to the doubly linked list at the hashed index
            size++;
        }
    }

    /**
     * Remove a string from the hash table.
     * 
     * @param s The string to be removed.
     * @return True if the string was found and removed, false otherwise.
     */
    public boolean remove(String s) {
        int index = h(s, table.length);  // Compute the hash value to find the index
        if (table[index].remove(s)) {  // If the string is found and removed
            size--;
            return true;
        }
        return false;  // Return false if the string wasn't found
    }

    /**
     * Check if a string is in the hash table.
     * 
     * @param s The string to check for.
     * @return True if the string is in the hash table, false otherwise.
     */
    public boolean contains(String s) {
        int index = h(s, table.length);  // Compute the hash value to find the index
        return table[index].contains(s);  // Check if the string is in the doubly linked list at that index
    }

    /**
     * Get the current number of elements in the hash table.
     * 
     * @return The size of the hash table.
     */
    public int size() {
        return size;
    }
    
    
    /**
     * Find and return a string from the hash table.
     * 
     * @param s The string to find.
     * @return The string if found, otherwise null.
     */
    public String find(String s) {
        int index = h(s, table.length);  // Compute the hash value to find the index
        if (table[index].contains(s)) {  // If the string is found
            return s;  // Return the string
        }
        return null;  // Return null if the string wasn't found
    }
}
