import static org.junit.Assert.*;
import org.junit.Test;
import student.TestCase;

/**
 * This is the test class for the Graph class
 * 
 * @author krishnapatel and nitinankareddy
 * @version Sep 17, 2024
 */
public class GraphTest  {

    private Graph graph;
    
    /**
     * This is the setup for the Graph tests
     */
    public void setUp() {
        graph = new Graph(3);
    }
    
    
    public void testInsert() {
        graph.graphInsert(1, 2);
        graph.graphInsert(3, 4);
        graph.graphInsert(5, 6);
        graph.graphInsert(7, 8);
        
        
    }
    
    public void testRemove() {
        graph.graphInsert(1, 2);
        graph.graphInsert(3, 4);
        graph.graphInsert(5, 6);
        graph.graphInsert(7, 8);
        
        graph.removeNode(6);
    }
    public void testConnectedComponents() {
        graph.graphInsert(1, 2);
        graph.graphInsert(3, 4);
        graph.graphInsert(5, 6);
        graph.graphInsert(7, 8);
        
        graph.connectedComponents();
        
    }
    
    
//    public void testNewNodes()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.newNode(10);
//        assertEquals(3, graph.getNumberOfNodes());
//        
//        graph.newNode(10);
//        assertEquals(4, graph.getNumberOfNodes());
//           
//    }
//    
//    public void testFreeSlots()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.removeNode(0);
//        graph.newNode(10);
//        assertFalse(graph.hasEdge(0, 1));
//    }
//    
//    public void testAddEdges()
//    {
//        assertFalse(graph.hasEdge(0, 1));
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.addEdge(0, 1);
//        graph.addEdge(0,0);
//        assertTrue(graph.hasEdge(0, 1));
//        assertTrue(graph.hasEdge(1, 0));
//        assertFalse(graph.hasEdge(1, 2));
//        assertTrue(graph.hasEdge(0,0));
//        
//    }
//    
//    public void testRemoveEdges()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.addEdge(0, 1);
//        graph.removeEdge(0,  1);
//        assertFalse(graph.hasEdge(0, 1));
//    }
//    
//    public void testRemoveNode()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.removeNode(0);
//        graph.newNode(10);
//        assertFalse(graph.hasEdge(0, 1));
//    }
//    
//    public void testNoEdge()
//    {
//        graph.addEdge(0, 1);
//        assertFalse(graph.hasEdge(0, 1));
//    }
//    
//    public void testInvalidEdges()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        assertFalse(graph.hasEdge(0,  2));
//        assertFalse(graph.hasEdge(2,  0)); 
//    }
//    
//    public void testNullNodes()
//    {
//        graph.hasEdge(0, 1);
//        assertFalse(graph.hasEdge(0, 1));
//        
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.addEdge(0, 1);
//        assertTrue(graph.hasEdge(0, 1));
//    }
//    
//    public void testRemoveNullNode()
//    {
//        graph.newNode(10);
//        graph.newNode(10);
//        graph.removeNode(0);
//        assertFalse(graph.hasEdge(0, 1));
//        
//        graph.removeNode(0);
//    }

    
    
    
    
    
}
