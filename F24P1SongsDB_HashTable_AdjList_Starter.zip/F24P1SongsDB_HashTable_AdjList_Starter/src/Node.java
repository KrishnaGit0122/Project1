public class Node {
    private int index;
    
    public Node(int index) {
        this.index = index;
    }

    // Getter for index
    public int getIndex() {
        return index;
    }

    // Setter for index
    public void setIndex(int index) {
        this.index = index;
    }
    
    


}
