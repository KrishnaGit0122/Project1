public class Node {
    private String index;
    
    public Node(String index) {
        this.index = index;
    }

    // Getter for index
    public String getIndex() {
        return index;
    }

    // Setter for index
    public void setIndex(String index) {
        this.index = index;
    }
    
    


}
